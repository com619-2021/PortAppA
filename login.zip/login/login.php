<!DOCTYPE html>
<html>
<head>
	<title> Portapplication A Login</title>
	<link rel="stylesheet" a href="style.css">
	<link rel="shortcut icon" type="image/jpg" href="login.png"/>

</head>
<body>
	<div class="container">
	<img src="login.png"/>
		<form>
			<div class="form-input">
				<input type="text" name="text" placeholder="Username"/>	
			</div>
			<div class="form-input">
				<input type="password" name="password" placeholder="password"/>
			</div>
			<input type="submit" type="submit" value="LOGIN" class="btn-login"/>
		</form>
	</div>
</body>
</html>